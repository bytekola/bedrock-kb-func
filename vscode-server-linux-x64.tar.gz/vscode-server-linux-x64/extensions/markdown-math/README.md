# Markdown Math

**Notice:** This extension is bundled with Visual Studio Code. It can be disabled but not uninstalled.

Adds math rendering using [KaTeX](https://katex.org) to VS Code's built-in markdown preview and markdown cells in notebooks.
